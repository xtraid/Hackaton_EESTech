
import numpy as np
from haversine import haversine, Unit

def required_power(mass, slope, speed_mps, C_r=0.0015, C_d=0.7, A=0.5, rho=1.225):
    """Potenza totale (W) necessaria a superare gravità, attrito e resistenza aero."""
    g = 9.81
    # Gravità (solo se salita)
    P_s = mass * g * slope * speed_mps if slope > 0 else 0.0
    # Attrito volvente
    P_f = C_r * mass * g * speed_mps
    # Resistenza aerodinamica
    P_r = 0.5 * C_d * rho * A * speed_mps ** 3
    return P_s + P_f + P_r

def motor_fraction(assist_level):
    """Restituisce frazione di potenza fornita dal motore dato il livello 1–5."""
    assist_level = max(1, min(5, assist_level))
    return 0.95 - 0.15 * assist_level  # 1→0.80, 5→0.20

def compute_segment_energy(lat1, lon1, alt1, lat2, lon2, alt2,
                           speed_kmh, mass, assist_level):
    """Energia batteria (Wh) e altri dati per un segmento tra due punti GPS."""
    # Distanza orizzontale in metri (Haversine)
    dist_m = haversine((lat1, lon1), (lat2, lon2), unit=Unit.METERS)
    if dist_m == 0:
        return 0.0, 0.0, 0.0  # Nessun movimento
    slope = (alt2 - alt1) / dist_m
    speed_mps = speed_kmh / 3.6
    seg_time = dist_m / speed_mps  # secondi
    P_tot = required_power(mass, slope, speed_mps)
    frac = motor_fraction(assist_level)
    P_motor = P_tot * frac
    P_human = P_tot - P_motor
    E_batt_Wh = (P_motor * seg_time) / 3600.0
    return E_batt_Wh, seg_time, P_human

def compute_route_energy(df_route, speed_kmh, mass, assist_level):
    """Calcola energia totale batteria, durata e picco potenza umana."""
    total_energy = 0.0
    total_time = 0.0
    peak_human = 0.0
    for i in range(len(df_route) - 1):
        lat1, lon1, alt1 = df_route.iloc[i][['lat', 'lon', 'alt']]
        lat2, lon2, alt2 = df_route.iloc[i + 1][['lat', 'lon', 'alt']]
        E_seg, t_seg, P_human = compute_segment_energy(
            lat1, lon1, alt1, lat2, lon2, alt2,
            speed_kmh, mass, assist_level
        )
        total_energy += E_seg
        total_time += t_seg
        peak_human = max(peak_human, P_human)
    return total_energy, total_time / 3600.0, peak_human

# ---------------------------------------------------------------------
# Algoritmo avanzato per livellare la potenza ciclista e ridurre stress batteria
# ---------------------------------------------------------------------
def compute_route_energy_smooth(df_route, speed_kmh, mass, assist_initial,
                                human_target=200, batt_power_limit=500,
                                batt_capacity_Wh=500):
    """Restituisce:
        - energia batteria totale (Wh)
        - durata giro (h)
        - picco potenza ciclista (W)
        - lista frazioni motore (profilo assistenza)
    L'algoritmo adegua la frazione motore per mantenere P_human <= human_target
    e P_motor <= batt_power_limit, cercando di ridurre variazioni brusche e
    preservare la batteria riducendo scariche profonde.
    """
    total_energy = 0.0
    total_time = 0.0
    peak_human = 0.0
    profile = []
    soc_Wh = batt_capacity_Wh * 0.75  # massimo spendibile (75%)
    frac_prev = motor_fraction(assist_initial)
    for i in range(len(df_route) - 1):
        lat1, lon1, alt1 = df_route.iloc[i][['lat', 'lon', 'alt']]
        lat2, lon2, alt2 = df_route.iloc[i + 1][['lat', 'lon', 'alt']]
        dist_m = haversine_distance(lat1, lon1, lat2, lon2)
        if dist_m == 0:
            profile.append(frac_prev)
            continue
        slope = (alt2 - alt1) / dist_m
        speed_mps = speed_kmh / 3.6
        seg_time = dist_m / speed_mps
        P_tot = required_power(mass, slope, speed_mps)

        # ---------------- dynamic adjust ----------------
        # minimo motore per rispettare target umano:
        P_motor_min = max(0.0, P_tot - human_target)
        # non superare limite batteria
        P_motor = min(P_motor_min, batt_power_limit)
        frac = P_motor / P_tot if P_tot > 0 else 0.0
        # limiti ragionevoli (0.2..0.95)
        frac = max(0.2, min(0.95, frac))
        # ammorbidisci transizione (filtro 1‑pole)
        alpha = 0.3
        frac = alpha * frac + (1 - alpha) * frac_prev
        frac_prev = frac
        profile.append(frac)

        P_motor = P_tot * frac
        P_human = P_tot - P_motor

        E_batt_seg = (P_motor * seg_time) / 3600.0
        # se rischia di superare SOC, riduci gradualmente motore
        if E_batt_seg > soc_Wh:
            scale = soc_Wh / E_batt_seg
            E_batt_seg *= scale
            P_motor *= scale
            P_human = P_tot - P_motor
            frac_prev = P_motor / P_tot
        soc_Wh -= E_batt_seg

        total_energy += E_batt_seg
        total_time += seg_time
        peak_human = max(peak_human, P_human)

    return total_energy, total_time / 3600.0, peak_human, profile

# Funzione Haversine indipendente per eliminare dipendenza esterna
def haversine_distance(lat1, lon1, lat2, lon2):
    R = 6371000  # raggio medio Terra in m
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlamb = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlamb / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))

# ---------------------------------------------------------------------
# Algoritmo con velocità variabile (adaptive) per evitare picchi umani
# ---------------------------------------------------------------------
def compute_route_energy_adaptive(df_route, base_speed_kmh, mass, assist_initial,
                                  human_target=200, batt_power_limit=500,
                                  batt_capacity_Wh=500, min_speed_kmh=8,
                                  max_speed_kmh=None):
    if max_speed_kmh is None:
        max_speed_kmh = base_speed_kmh * 1.7
    total_energy = 0.0
    total_time = 0.0
    peak_human = 0.0
    speed_profile = []
    assist_profile = []
    soc_Wh = batt_capacity_Wh * 0.75
    frac_prev = motor_fraction(assist_initial)

    for i in range(len(df_route) - 1):
        lat1, lon1, alt1 = df_route.iloc[i][['lat', 'lon', 'alt']]
        lat2, lon2, alt2 = df_route.iloc[i + 1][['lat', 'lon', 'alt']]
        dist_m = haversine_distance(lat1, lon1, lat2, lon2)
        if dist_m == 0:
            speed_profile.append(base_speed_kmh)
            assist_profile.append(frac_prev)
            continue
        slope = (alt2 - alt1) / dist_m

        # Determine speed target depending on slope
        speed_kmh = base_speed_kmh
        if slope > 0.01:          # salita
            speed_kmh = max(min_speed_kmh, base_speed_kmh * (1 - slope * 5))
        elif slope < -0.02:       # discesa
            speed_kmh = min(max_speed_kmh, base_speed_kmh * (1 - slope * 5))
        # else: moderate slope keep base

        # iterate to satisfy human_target
        while True:
            speed_mps = speed_kmh / 3.6
            seg_time = dist_m / speed_mps
            P_tot = required_power(mass, slope, speed_mps)
            # start with previous fraction
            frac = frac_prev
            P_motor = P_tot * frac
            P_motor = min(P_motor, batt_power_limit)
            P_human = P_tot - P_motor
            if P_human > human_target and speed_kmh > min_speed_kmh:
                speed_kmh = max(min_speed_kmh, speed_kmh - 1)
                continue
            if P_human > human_target:
                # increase motor
                needed_motor = P_tot - human_target
                P_motor = min(needed_motor, batt_power_limit)
                frac = P_motor / P_tot
                P_human = P_tot - P_motor
            break  # exit loop

        # smooth fraction
        alpha = 0.3
        frac = alpha * frac + (1 - alpha) * frac_prev
        frac_prev = frac
        P_motor = P_tot * frac
        P_human = P_tot - P_motor

        # energy for segment
        E_batt_seg = (P_motor * seg_time) / 3600.0
        if E_batt_seg > soc_Wh:
            scale = soc_Wh / E_batt_seg
            E_batt_seg *= scale
            P_motor *= scale
            P_human = P_tot - P_motor
            frac_prev = P_motor / P_tot
        soc_Wh -= E_batt_seg

        total_energy += E_batt_seg
        total_time += seg_time
        peak_human = max(peak_human, P_human)
        speed_profile.append(speed_kmh)
        assist_profile.append(frac)

    return (total_energy, total_time / 3600.0, peak_human,
            speed_profile, assist_profile)

def compute_profile_with_elevation(df_route, base_speed_kmh, mass, assist_initial,
                                   human_target=200, batt_power_limit=500,
                                   batt_capacity_Wh=500, speed_min_kmh=8,
                                   speed_max_kmh=None):
    """Restituisce liste:
        cum_dist_km, cum_time_h, elev_m, P_motor_W
    regolando velocità entro un range min/max, spegnendo il motore in discesa,
    e livellando l'assistenza per ridurre i picchi di sforzo.
    """
    if speed_max_kmh is None:
        speed_max_kmh = base_speed_kmh * 1.7
    g = 9.81
    cum_dist = 0.0
    cum_time = 0.0
    cum_dist_list = []
    cum_time_list = []
    elev_list = []
    P_motor_list = []
    soc_Wh = batt_capacity_Wh * 0.75
    frac_prev = motor_fraction(assist_initial)

    for i in range(len(df_route) - 1):
        lat1, lon1, alt1 = df_route.iloc[i][['lat', 'lon', 'alt']]
        lat2, lon2, alt2 = df_route.iloc[i+1][['lat', 'lon', 'alt']]
        dist_m = haversine_distance(lat1, lon1, lat2, lon2)
        if dist_m == 0:
            continue
        slope = (alt2 - alt1) / dist_m
        # speed target
        speed_kmh = base_speed_kmh
        if slope > 0.01:
            speed_kmh = max(speed_min_kmh, base_speed_kmh * (1 - slope*5))
        elif slope < -0.02:
            speed_kmh = min(speed_max_kmh, base_speed_kmh * (1 - slope*5))
        speed_mps = speed_kmh / 3.6
        seg_time = dist_m / speed_mps
        P_tot = required_power(mass, slope, speed_mps)
        # motore OFF in discesa leggera (< -2%) se potenza tot < 80 W
        if slope < -0.02 and P_tot < 80:
            P_motor = 0.0
            P_human = P_tot
            frac_prev = 0.0
        else:
            # calcola frazione motore
            frac = frac_prev
            P_motor = min(P_tot * frac, batt_power_limit)
            P_human = P_tot - P_motor
            # se ciclista supera target, aumenta motore
            if P_human > human_target:
                P_motor = min(P_tot - human_target, batt_power_limit)
                frac = P_motor / P_tot if P_tot else 0.0
                P_human = P_tot - P_motor
            # filtro
            alpha = 0.3
            frac = alpha*frac + (1-alpha)*frac_prev
            frac_prev = frac
            P_motor = P_tot * frac
            P_human = P_tot - P_motor
        E_seg_Wh = (P_motor * seg_time) / 3600.0
        if E_seg_Wh > soc_Wh:
            scale = soc_Wh / E_seg_Wh
            P_motor *= scale
            P_human = P_tot - P_motor
            E_seg_Wh *= scale
            frac_prev = P_motor / P_tot if P_tot else 0.0
        soc_Wh -= E_seg_Wh

        # accumulate
        cum_dist += dist_m / 1000.0
        cum_time += seg_time / 3600.0
        cum_dist_list.append(cum_dist)
        cum_time_list.append(cum_time)
        elev_list.append(alt2)
        P_motor_list.append(P_motor)
    return cum_time_list, elev_list, P_motor_list
