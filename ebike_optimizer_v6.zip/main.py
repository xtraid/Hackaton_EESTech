
import argparse
import pandas as pd
from power_model import (compute_route_energy,
                         compute_route_energy_smooth,
                         compute_route_energy_adaptive)
from battery_soh import BatterySOHModel

def parse_args():
    p = argparse.ArgumentParser(description="Valuta la fattibilità di un giro in e‑bike.")
    p.add_argument("--route", default="ebike_data.csv", help="CSV con lat, lon, alt.")
    p.add_argument("--speed", type=float, default=15, help="Velocità media base km/h.")
    p.add_argument("--assist", type=int, default=3, help="Livello assistenza iniziale 1‑5.")
    p.add_argument("--mass", type=float, default=90, help="Massa bici+ciclista kg.")
    p.add_argument("--battery", type=float, default=500, help="Capacità batteria Wh.")
    p.add_argument("--time_limit", type=float, default=3, help="Tempo massimo ore.")
    p.add_argument("--batt_limit", type=float, default=75, help="Max % batteria da usare.")
    p.add_argument("--human_limit", type=float, default=250, help="Picco potenza umana W.")
    p.add_argument("--smooth", action="store_true",
                   help="Usa assistenza dinamica con velocità costante.")
    p.add_argument("--adaptive", action="store_true",
                   help="Usa velocità variabile per evitare picchi di potenza umana.")
    return p.parse_args()

def main():
    args = parse_args()
    df = pd.read_csv(args.route)
    if not {'lat','lon','alt'}.issubset(df.columns):
        raise ValueError("Il CSV deve contenere colonne: lat, lon, alt")
    if args.adaptive:
        res = compute_route_energy_adaptive(
            df, args.speed, args.mass, args.assist,
            human_target=args.human_limit,
            batt_power_limit=500,
            batt_capacity_Wh=args.battery
        )
        E_batt, hours, human_peak, speed_prof, assist_prof = res
        avg_speed = sum(speed_prof)/len(speed_prof)
        print(f"Velocità media effettiva:   {avg_speed:.1f} km/h")
    elif args.smooth:
        E_batt, hours, human_peak, assist_prof = compute_route_energy_smooth(
            df, args.speed, args.mass, args.assist,
            human_target=args.human_limit,
            batt_power_limit=500,
            batt_capacity_Wh=args.battery
        )
        speed_prof = None
    else:
        E_batt, hours, human_peak = compute_route_energy(
            df, args.speed, args.mass, args.assist
        )
        speed_prof = assist_prof = None

    print(f"Energia batteria richiesta: {E_batt:.1f} Wh")
    print(f"Durata stimata giro:       {hours:.2f} h")
    print(f"Picco potenza ciclista:    {human_peak:.0f} W")
    feasible = True
    if hours > args.time_limit:
        print("✗ Non fattibile: supera il tempo massimo.")
        feasible = False
    if E_batt > args.battery * args.batt_limit / 100:
        print("✗ Non fattibile: consumo batteria oltre limite.")
        feasible = False
    if human_peak > args.human_limit:
        print("✗ Non fattibile: picco potenza ciclista alto.")
        feasible = False
    if feasible:
        print("✓ Percorso fattibile con i parametri dati.")
    # Aggiorna SOH
    soh_model = BatterySOHModel(args.battery)
    soh_model.apply_usage(E_batt)
    
    # ----- Summary table -------------------------------------------------
    summary = pd.DataFrame({
        "Energia_batt_Wh": [round(E_batt,1)],
        "Durata_h": [round(hours,2)],
        "Picco_P_ciclista_W": [round(human_peak)],
        "SOH_%": [round(soh_model.SOH*100,2)]
    })
    print("\nSummary table:")
    print(summary.to_string(index=False))

if __name__ == "__main__":
    main()
