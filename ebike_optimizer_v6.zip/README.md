
# eBike Optimizer

Algoritmo in Python per stimare:
1. **Fattibilità** di un giro in e‑bike dati velocità, livello di assistenza, tempo massimo e batteria disponibile.
2. **Energia** richiesta alla batteria in ogni segmento del percorso.
3. **Picco di potenza** richiesto al ciclista.
4. **Impatto sullo stato di salute (SOH)** della batteria in termini di cicli equivalenti.

## Struttura del Progetto
```
ebike_optimizer/
├── battery_soh.py      # Modello di degradazione SOH
├── power_model.py      # Modelli fisici potenza / energia
├── main.py             # Script CLI di esempio
├── ebike_data.csv      # Esempio di percorso (lat, lon, alt)
└── requirements.txt    # Dipendenze Python
```

## Installazione
```bash
python -m venv venv && source venv/bin/activate   # (opzionale) ambiente virtuale
pip install -r requirements.txt
```

## Uso rapido
```bash
python main.py --route ebike_data.csv --speed 18 --assist 2 --time_limit 2.5
```
Parametri principali:
- `--speed` velocità media in km/h
- `--assist` livello di assistenza 1 (massimo aiuto) – 5 (minimo aiuto)
- `--time_limit` tempo massimo (h)
- `--batt_limit` percentuale massima di batteria utilizzabile (default 75)

Il programma stampa:
- Energia totale richiesta (Wh)
- Durata stimata del giro
- Picco di potenza umana
- Esito di fattibilità
- Nuovo SOH stimato

## Dataset NASA (opzionale)
Per un modello più accurato di degradazione, scaricare il dataset NASA:
https://www.kaggle.com/datasets/patrickfleith/nasa-battery-dataset  
e adattere `battery_soh.py` di conseguenza inserendo i parametri specifici delle celle.

## Dipendenze
Vedi `requirements.txt`.
