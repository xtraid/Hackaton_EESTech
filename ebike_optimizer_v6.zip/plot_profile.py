
"""Script di utilità per generare un grafico potenza‒dislivello."""
import argparse, pandas as pd, matplotlib.pyplot as plt
from power_model import compute_profile_with_elevation

parser = argparse.ArgumentParser(description="Plot potenza motore vs elevazione.")
parser.add_argument("--route", default="ebike_data.csv")
parser.add_argument("--speed", type=float, default=15)
parser.add_argument("--assist", type=int, default=3)
parser.add_argument("--mass", type=float, default=90)
args = parser.parse_args()

df = pd.read_csv(args.route)
df = df.rename(columns={'latitude':'lat','longitude':'lon','elevation':'alt'})
t, elev, Pm = compute_profile_with_elevation(df, args.speed, args.mass, args.assist)

fig, ax1 = plt.subplots()
ax1.plot(t, Pm, color="tab:orange", label="Potenza motore")
ax1.set_xlabel("Tempo (h)")
ax1.set_ylabel("Potenza motore (W)", color="tab:orange")
ax1.tick_params(axis='y', labelcolor="tab:orange")

ax2 = ax1.twinx()
ax2.plot(t, elev, color="tab:blue", alpha=0.5, label="Altitudine")
ax2.set_ylabel("Altitudine (m)", color="tab:blue")
ax2.tick_params(axis='y', labelcolor="tab:blue")

plt.title("Potenza motore vs Altitudine")
fig.tight_layout()
plt.show()
