import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, Map, ArrowRight, Check } from 'lucide-react';
import { useBatteryContext } from '../context/BatteryContext';
import RouteElevationChart from '../components/charts/RouteElevationChart';
import toast from 'react-hot-toast';

const RouteAnalysis: React.FC = () => {
  const navigate = useNavigate();
  const { setRouteData, routeData } = useBatteryContext();
  const [isUploading, setIsUploading] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    
    setFileName(file.name);
    setIsUploading(true);
    
    // Simulate file processing
    setTimeout(() => {
      const reader = new FileReader();
      
      reader.onload = (e) => {
        try {
          // For demonstration purposes, we'll create mock data
          // In a real app, you would parse the actual CSV/GPX file
          const mockRouteData = generateMockRouteData();
          setRouteData(mockRouteData);
          setIsUploading(false);
          toast.success('Route data uploaded successfully!');
        } catch (error) {
          console.error('Error parsing route data:', error);
          setIsUploading(false);
          toast.error('Failed to parse route data. Please check the file format.');
        }
      };
      
      reader.onerror = () => {
        setIsUploading(false);
        toast.error('Error reading file');
      };
      
      reader.readAsText(file);
    }, 1500);
  };
  
  const generateMockRouteData = () => {
    // Generate a circular route with varying elevation
    const points = 100;
    const data = [];
    
    for (let i = 0; i < points; i++) {
      const progress = i / points;
      const angle = progress * Math.PI * 2;
      
      // Create a circular path
      const radius = 0.01;
      const lat = 41.9028 + Math.cos(angle) * radius;
      const lng = 12.4964 + Math.sin(angle) * radius;
      
      // Add varying elevation with hills
      let elevation;
      if (progress < 0.25) {
        elevation = 100 + progress * 4 * 300; // Uphill
      } else if (progress < 0.5) {
        elevation = 400 - (progress - 0.25) * 4 * 200; // Downhill
      } else if (progress < 0.75) {
        elevation = 200 + (progress - 0.5) * 4 * 250; // Another uphill
      } else {
        elevation = 450 - (progress - 0.75) * 4 * 350; // Back down to starting point
      }
      
      data.push({
        latitude: lat,
        longitude: lng,
        elevation: elevation,
        distance: progress * 10, // Total distance of 10km
      });
    }
    
    return data;
  };
  
  const handleContinue = () => {
    navigate('/battery-optimizer');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-2xl font-bold text-gray-800">Route Analysis</h1>
        <p className="text-gray-600">
          Upload your route data to analyze the elevation profile and prepare for optimization.
        </p>
      </div>
      
      {!routeData ? (
        <div className="bg-white rounded-lg shadow-md p-8 border border-dashed border-gray-300">
          <div className="flex flex-col items-center text-center">
            <Map className="w-16 h-16 text-green-500 mb-4" />
            <h2 className="text-xl font-semibold text-gray-800 mb-2">Upload Route Data</h2>
            <p className="text-gray-600 mb-6 max-w-md">
              Upload your cycling route in GPX, CSV, or TCX format. The file should include latitude, 
              longitude, and elevation data for best results.
            </p>
            
            <label className="relative cursor-pointer bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-md transition-colors inline-flex items-center">
              <Upload className="w-5 h-5 mr-2" />
              <span>{isUploading ? 'Uploading...' : 'Select Route File'}</span>
              <input 
                type="file" 
                className="hidden" 
                accept=".gpx,.csv,.tcx" 
                onChange={handleFileUpload}
                disabled={isUploading}
              />
            </label>
            
            {fileName && (
              <div className="mt-4 text-sm text-gray-600 flex items-center">
                <Check className="w-4 h-4 mr-1 text-green-500" />
                Selected file: {fileName}
              </div>
            )}
          </div>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Route Elevation Profile</h2>
            <div className="h-64">
              <RouteElevationChart routeData={routeData} />
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-semibold text-gray-800 mb-4">Route Statistics</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-gray-50 p-4 rounded-md">
                <p className="text-sm text-gray-500">Total Distance</p>
                <p className="text-2xl font-bold text-gray-800">10.0 km</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-md">
                <p className="text-sm text-gray-500">Elevation Gain</p>
                <p className="text-2xl font-bold text-gray-800">550 m</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-md">
                <p className="text-sm text-gray-500">Max Elevation</p>
                <p className="text-2xl font-bold text-gray-800">450 m</p>
              </div>
              <div className="bg-gray-50 p-4 rounded-md">
                <p className="text-sm text-gray-500">Estimated Duration</p>
                <p className="text-2xl font-bold text-gray-800">45 min</p>
              </div>
            </div>
          </div>
          
          <div className="flex justify-end">
            <button
              onClick={handleContinue}
              className="inline-flex items-center px-4 py-2 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors"
            >
              Continue to Battery Optimizer <ArrowRight className="ml-2 w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default RouteAnalysis;