import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Battery, ArrowRight, AlertTriangle, CheckCircle, X } from 'lucide-react';
import { useBatteryContext } from '../context/BatteryContext';
import RouteElevationChart from '../components/charts/RouteElevationChart';
import PowerAllocationChart from '../components/charts/PowerAllocationChart';
import toast from 'react-hot-toast';

const BatteryOptimizer: React.FC = () => {
  const navigate = useNavigate();
  const { routeData, setOptimizationResult } = useBatteryContext();
  
  const [effortLevel, setEffortLevel] = useState<number>(3);
  const [speedMode, setSpeedMode] = useState<string>('City');
  const [completionTime, setCompletionTime] = useState<number>(45);
  const [weight, setWeight] = useState<number>(75);
  const [isOptimizing, setIsOptimizing] = useState<boolean>(false);
  const [optimizationResult, setLocalOptimizationResult] = useState<any>(null);
  const [showAdvancedOptions, setShowAdvancedOptions] = useState<boolean>(false);
  
  useEffect(() => {
    if (!routeData) {
      navigate('/route-analysis');
    }
  }, [routeData, navigate]);
  
  const handleOptimize = () => {
    if (!routeData) return;
    
    setIsOptimizing(true);
    
    // Simulate optimization calculation
    setTimeout(() => {
      const result = calculateOptimization();
      setLocalOptimizationResult(result);
      setOptimizationResult(result);
      setIsOptimizing(false);
      
      if (result.isFeasible) {
        toast.success('Optimization completed successfully!');
      } else {
        toast.error('Route cannot be completed with the given parameters.');
      }
    }, 2000);
  };
  
  const calculateOptimization = () => {
    // Check if the route is feasible with given parameters
    const isFeasible = effortLevel >= 2 || completionTime >= 40;
    
    // Calculate battery end level (minimum 25%)
    let batteryEnd = 100 - (10 * effortLevel);
    if (batteryEnd < 25) batteryEnd = 25;
    
    // Calculate power allocation per segment
    const powerAllocation = routeData?.map((point, index) => {
      const nextPoint = routeData[index + 1] || point;
      const elevationChange = nextPoint.elevation - point.elevation;
      
      // Base power is inversely proportional to effort level
      // Lower effort = more battery power
      let power = 1 - (effortLevel - 1) * 0.15; // This gives higher power for lower effort
      
      // Adjust for terrain
      if (elevationChange > 5) {
        // Uphill needs more power
        power *= 1.3;
      } else if (elevationChange < -5) {
        // Downhill needs less power
        power *= 0.5;
      }
      
      // Adjust for speed mode
      if (speedMode === 'Eco') power *= 0.8;
      if (speedMode === 'Sport') power *= 1.2;
      
      return Math.min(Math.max(power, 0.1), 1); // Ensure power is between 10% and 100%
    }) || [];
    
    // Calculate SOH impact based on power usage patterns
    const avgPower = powerAllocation.reduce((sum, power) => sum + power, 0) / powerAllocation.length;
    const baseSOHDrop = 0.003;
    const effortMultiplier = (effortLevel / 5); // Higher effort = less battery stress
    const estimatedSOHDrop = baseSOHDrop * avgPower * effortMultiplier;
    
    return {
      isFeasible,
      batteryStart: 100,
      batteryEnd,
      powerAllocation,
      estimatedSOHDrop,
      estimatedLifespanExtension: Math.floor(100 / estimatedSOHDrop),
      completionTime: isFeasible ? completionTime : completionTime * 1.3,
    };
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col space-y-2">
        <h1 className="text-2xl font-bold text-gray-800">Battery Optimizer</h1>
        <p className="text-gray-600">
          Set your preferences and optimize battery usage for your route.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-lg font-semibold text-gray-800 mb-4">Rider Preferences</h2>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Effort Level (1-5)
                </label>
                <div className="flex items-center space-x-2">
                  <input
                    type="range"
                    min="1"
                    max="5"
                    value={effortLevel}
                    onChange={(e) => setEffortLevel(parseInt(e.target.value))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-green-500"
                  />
                  <span className="text-gray-800 font-semibold">{effortLevel}</span>
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Higher effort means you do more work and use less battery.
                </p>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Speed Mode
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['Eco', 'City', 'Sport'].map((mode) => (
                    <button
                      key={mode}
                      onClick={() => setSpeedMode(mode)}
                      className={`py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                        speedMode === mode
                          ? 'bg-green-500 text-white'
                          : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                      }`}
                    >
                      {mode}
                    </button>
                  ))}
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Desired Completion Time (minutes)
                </label>
                <input
                  type="number"
                  value={completionTime}
                  onChange={(e) => setCompletionTime(parseInt(e.target.value))}
                  min="20"
                  max="120"
                  className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                />
              </div>
              
              <div>
                <button
                  onClick={() => setShowAdvancedOptions(!showAdvancedOptions)}
                  className="text-sm text-green-600 hover:text-green-700 flex items-center"
                >
                  {showAdvancedOptions ? (
                    <>
                      <X className="w-4 h-4 mr-1" /> Hide Advanced Options
                    </>
                  ) : (
                    <>
                      <ArrowRight className="w-4 h-4 mr-1" /> Show Advanced Options
                    </>
                  )}
                </button>
              </div>
              
              {showAdvancedOptions && (
                <div className="pt-2 space-y-4 border-t border-gray-200">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Rider Weight (kg)
                    </label>
                    <input
                      type="number"
                      value={weight}
                      onChange={(e) => setWeight(parseInt(e.target.value))}
                      min="40"
                      max="150"
                      className="w-full p-2 border border-gray-300 rounded-md focus:ring-green-500 focus:border-green-500"
                    />
                  </div>
                </div>
              )}
              
              <button
                onClick={handleOptimize}
                disabled={isOptimizing}
                className="w-full py-2 px-4 bg-green-500 text-white rounded-md hover:bg-green-600 transition-colors flex justify-center items-center"
              >
                {isOptimizing ? (
                  <>
                    <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Optimizing...
                  </>
                ) : (
                  <>
                    <Battery className="w-5 h-5 mr-2" />
                    Optimize Battery Usage
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-2 space-y-6">
          {routeData && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <h2 className="text-lg font-semibold text-gray-800 mb-4">Route Elevation Profile</h2>
              <div className="h-48">
                <RouteElevationChart routeData={routeData} />
              </div>
            </div>
          )}
          
          {optimizationResult && (
            <>
              <div className={`rounded-lg shadow-md p-6 ${
                optimizationResult.isFeasible ? 'bg-green-50' : 'bg-red-50'
              }`}>
                <div className="flex items-start">
                  {optimizationResult.isFeasible ? (
                    <CheckCircle className="w-6 h-6 text-green-500 mr-3 flex-shrink-0" />
                  ) : (
                    <AlertTriangle className="w-6 h-6 text-red-500 mr-3 flex-shrink-0" />
                  )}
                  <div>
                    <h2 className="text-lg font-semibold text-gray-800">
                      {optimizationResult.isFeasible 
                        ? 'Route is Feasible' 
                        : 'Route May Not Be Feasible'
                      }
                    </h2>
                    <p className="text-gray-600">
                      {optimizationResult.isFeasible 
                        ? 'You can complete this route with the given parameters while maintaining battery health.'
                        : 'This route may be challenging to complete with your current settings. Consider increasing effort level or completion time.'
                      }
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6">
                <h2 className="text-lg font-semibold text-gray-800 mb-4">Optimization Results</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                  <div className="bg-gray-50 p-4 rounded-md">
                    <p className="text-sm text-gray-500">Battery Start Level</p>
                    <p className="text-2xl font-bold text-gray-800">{optimizationResult.batteryStart}%</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-md">
                    <p className="text-sm text-gray-500">Battery End Level</p>
                    <p className="text-2xl font-bold text-gray-800">{optimizationResult.batteryEnd}%</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-md">
                    <p className="text-sm text-gray-500">Estimated SOH Impact</p>
                    <p className="text-2xl font-bold text-gray-800">{(optimizationResult.estimatedSOHDrop * 100).toFixed(2)}%</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-md">
                    <p className="text-sm text-gray-500">Battery Lifespan Extension</p>
                    <p className="text-2xl font-bold text-gray-800">~{optimizationResult.estimatedLifespanExtension} cycles</p>
                  </div>
                </div>
                
                <h3 className="text-md font-semibold text-gray-800 mb-3">Power Allocation by Segment</h3>
                <div className="h-48">
                  <PowerAllocationChart 
                    routeData={routeData} 
                    powerAllocation={optimizationResult.powerAllocation}
                  />
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default BatteryOptimizer;